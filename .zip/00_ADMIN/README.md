# 00_ADMIN – Yönetim ve Yasal Belgeler

Bu klasör, radyonun tüm resmi ve yasal belgelerini içerir.

## İçerik:
- Tüzük
- Digris sözleşmeleri
- SUISA / IFPI belgeleri
- Sigorta poliçeleri
- Ticaret / dernek kayıtları
- Lisanslar

## Dosya İsimlendirme:
[YYYY]-ADMIN-[BelgeAdi].pdf
