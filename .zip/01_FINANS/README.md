# 01_FINANS – Finansal Kayıtlar

Gelir, gider, faturalar ve yıllık finansal raporlar burada tutulur.

## Alt klasörler:
- 2026/
- 2027/
- 2028/

## Dosya İsimlendirme:
[YYYY]-FINANS-[Konu].xlsx
