# 02_YAYIN – Yayın Akışı ve İçerik

Program akışları, haber metinleri, röportaj soruları ve topluluk duyuruları burada tutulur.

## Dosya İsimlendirme:
[YYYY]-YAYIN-[ProgramAdi]-[Hafta].docx
