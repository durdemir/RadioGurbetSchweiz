# 05_BRANDING – Marka Kimliği

Logo, renk paleti, tipografi ve tasarım dosyaları burada tutulur.

## Dosya İsimlendirme:
[YYYY]-BRANDING-[DosyaAdi]-V1.png
