# 06_STUDYO – Stüdyo Kurulumu

Ekipman listesi, bağlantı şemaları ve ses ayarları burada tutulur.

## Dosya İsimlendirme:
[YYYY]-STUDYO-[BelgeAdi].pdf
