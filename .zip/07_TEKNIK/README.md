# 07_TEKNIK – Teknik Dokümantasyon

Encoder ayarları, Digris teknik gereksinimleri ve monitoring araçları burada tutulur.

## Dosya İsimlendirme:
[YYYY]-TEKNIK-[Konu].docx
