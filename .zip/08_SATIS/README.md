# 08_SATIS – Reklam ve Sponsorluk

Müşteri listeleri, teklif şablonları ve satış pipeline burada tutulur.

## Dosya İsimlendirme:
[YYYY]-SATIS-[MusteriAdi]-Teklif.docx
