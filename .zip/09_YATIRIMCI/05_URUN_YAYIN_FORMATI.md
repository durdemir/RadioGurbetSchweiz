# GURBET RADIO SCHWEIZ – ÜRÜN / YAYIN FORMATİ

## 1) Günlük Haber Bülteni
- İsviçre gündemi
- Türkiye gündemi
- Diaspora haberleri
- Kısa, net, güvenilir içerik

---

## 2) Müzik Yayınları (Lisanslı)
- Türkçe pop
- Arabesk / fantezi
- Halk müziği
- Genç diaspora için modern remix ve alternatif müzik
- İsviçre’de yaşayan Türk sanatçılara özel alan

---

## 3) Topluluk Programları
- Göçmenlik hikâyeleri
- Dernekler, kültür merkezleri, etkinlik duyuruları
- Röportajlar
- “Gurbetteki Anadolunun Sesi” temasına uygun kültürel içerikler

---

## 4) Gençlik İçerikleri
- İki dilli (Türkçe + Almanca) programlar
- Genç diaspora sorunları
- Eğitim, kariyer, sosyal yaşam
- Podcast formatında kısa bölümler

---

## 5) Röportajlar
- İş insanları
- Sanatçılar
- Sporcular
- Topluluk liderleri
- Başarı hikâyeleri

---

## 6) Podcast Serileri
- Her programın podcast versiyonu
- Haftalık özel seriler
- Diaspora hikâyeleri
- Kültürel anlatılar

---

## 7) Canlı Yayınlar
- Günlük canlı yayın akışı
- Dinleyici mesajları
- Canlı telefon bağlantıları
- Özel günlerde özel yayınlar

---

## 8) Dijital Yayın Ekosistemi
- DAB+ yayın
- Online stream
- Mobil uygulama (gelecek planı)
- Sosyal medya entegrasyonu
