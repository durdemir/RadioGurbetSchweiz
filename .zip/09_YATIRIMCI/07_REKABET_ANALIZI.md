# GURBET RADIO SCHWEIZ – REKABET ANALİZİ

## 1) Türkiye Merkezli Diaspora Radyoları
- İsviçre’ye özel içerik üretmiyorlar
- Yerel topluluk haberleri yok
- Genç diaspora için yetersiz
- Reklam hedeflemesi zayıf

---

## 2) İsviçre Yerel Radyoları
- Türkçe yayın yok
- Diaspora odaklı program yok
- Kültürel bağ kuramıyorlar

---

## 3) YouTube / Podcast Kanalları
- Dağınık içerik
- Süreklilik yok
- Profesyonel yayın akışı yok
- Topluluk birleştirme gücü sınırlı

---

## 4) Gurbet Radio Schweiz’in Avantajları
- **İki dilli yayın (Türkçe + Almanca)**
- **Diaspora odaklı profesyonel format**
- **DAB+ + online yayın**
- **Topluluk merkezli içerik**
- **Gurbetteki Anadolunun Sesi** sloganıyla güçlü kimlik
- **Reklam verenler için hedefli erişim**

---

## 5) Sonuç
İsviçre’de Türk diasporasına yönelik profesyonel, iki dilli, sürekli yayın yapan **hiçbir radyo yok**.

Gurbet Radio Schweiz bu boşluğu dolduran **ilk ve tek** platformdur.
