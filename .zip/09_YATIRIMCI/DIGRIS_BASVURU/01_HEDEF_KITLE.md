# GURBET RADIO SCHWEIZ – HEDEF KITLE SEGMENTASYONU

## 1) Genç Diaspora (18–30)
- İsviçre’de doğmuş veya küçük yaşta gelmiş gençler
- Türkçe + Almanca karışık konuşan kuşak
- Spotify, YouTube, TikTok ağırlıklı medya tüketicileri

**Sunulan içerikler:**
- Modern müzik
- Gençlik programları
- İki dilli içerik
- Podcast serileri
- Sosyal medya entegrasyonu

---

## 2) Aile Segmenti (30–50)
- İş hayatında aktif
- Çocuklu aileler
- Hem Türkiye hem İsviçre gündemini takip edenler

**Sunulan içerikler:**
- Haber bültenleri
- Topluluk programları
- Kültürel içerikler
- Ekonomi ve günlük yaşam programları

---

## 3) Birinci Nesil Göçmenler (50+)
- Türkiye’den yetişkin yaşta gelmiş
- Türkçe içerik ağırlıklı tüketen
- Topluluk bağları güçlü

**Sunulan içerikler:**
- Türkçe müzik
- Klasik radyo formatı
- Topluluk haberleri
- Röportajlar

---

## 4) İsviçreli / Almanca Konuşan Dinleyiciler
- Türk kültürüne ilgi duyan İsviçreliler
- Türk partneri olanlar
- Almanca içerik arayan genç diaspora

**Sunulan içerikler:**
- Almanca kısa haberler
- İki dilli programlar
- Kültürel köprü içerikleri

---

## Özet
Gurbet Radio Schweiz, İsviçre’deki Türk diasporasının tüm yaş gruplarına hitap eden, segmentlenmiş ve iki dilli bir yayın stratejisiyle topluluğu bir araya getirir.
