# GURBET RADIO SCHWEIZ – SLOGAN

## Resmî Slogan
**Gurbetteki Anadolunun Sesi**

## Açıklama
Bu slogan, İsviçre’de yaşayan Türk diasporasının kültürel köklerini, aidiyet duygusunu ve topluluk bağlarını temsil eder. Gurbet Radio Schweiz, Anadolunun sıcaklığını ve sesini Avrupa’daki Türk toplumuna taşıyan bir köprü görevi görür.
