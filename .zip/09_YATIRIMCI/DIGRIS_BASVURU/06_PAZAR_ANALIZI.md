# GURBET RADIO SCHWEIZ – PAZAR ANALİZİ

## 1) İsviçre’deki Türk Diasporası
- 130.000+ Türk kökenli insan
- Yoğun olarak Zürich, Basel, Bern, Aargau, St. Gallen
- Genç kuşak iki dilli (Türkçe + Almanca)
- Aile yapısı güçlü, topluluk bilinci yüksek

---

## 2) Medya Tüketim Alışkanlıkları
- Gençler: Spotify, YouTube, TikTok, Podcast
- Yetişkinler: Radyo, TV, Facebook
- Birinci nesil: Klasik radyo + Türk TV kanalları
- Ortak nokta: **Türkçe içerik ihtiyacı**

---

## 3) Reklam Potansiyeli
Türk topluluğuna ulaşmak isteyen sektörler:
- Restoranlar
- Avukatlar
- Sigorta şirketleri
- Göçmenlik danışmanları
- Marketler
- Etkinlik organizatörleri
- Sağlık ve güzellik sektörü

---

## 4) Fırsat
İsviçre’de Türkçe + Almanca hibrit yayın yapan **profesyonel bir radyo yok**.

Gurbet Radio Schweiz bu boşluğu doldurarak:
- Topluluğu bir araya getirir
- Reklam verenlere hedefli erişim sağlar
- Diaspora için kültürel bir merkez oluşturur
