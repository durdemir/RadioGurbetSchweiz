# GURBET RADIO SCHWEIZ – İŞ MODELİ

## 1) Reklam Gelirleri
- Yerel işletmeler (restoran, market, avukat, sigorta)
- Etkinlik organizatörleri
- Kültürel dernekler
- Hedefli reklam paketleri (gençlik, aile, diaspora)

---

## 2) Sponsorluk
- Program sponsorluğu
- Haftalık/aylık özel yayın sponsorluğu
- Podcast serisi sponsorluğu
- “Gurbetteki Anadolunun Sesi” temalı kültürel sponsor paketleri

---

## 3) Dijital Reklam
- Web sitesi banner reklamları
- Mobil uygulama reklamları (gelecek planı)
- Podcast içi reklam spotları

---

## 4) Etkinlik Ortaklıkları
- Diaspora festivalleri
- Kültürel etkinlikler
- Konserler
- Topluluk buluşmaları

---

## 5) Premium İçerik (Gelecek Planı)
- Ücretli özel podcast serileri
- Üyelik sistemi
- Reklamsız dinleme

---

## 6) Sonuç
Gurbet Radio Schweiz, hem geleneksel radyo gelir modellerini hem de modern dijital medya gelirlerini birleştiren hibrit bir iş modeline sahiptir.
