# GURBET RADIO SCHWEIZ – TEKNİK ALTYAPI

## 1) Yayın Altyapısı
- Digris DAB+ ağına başvuru
- DAB+ üzerinden İsviçre genelinde yayın
- Online stream (web + mobil)

---

## 2) Stüdyo Ekipmanı
- Profesyonel mikrofonlar
- Ses kartı
- Mikser
- Yayın kulaklıkları
- Akustik düzenleme

---

## 3) Yayın Yazılımı
- Otomasyon yazılımı
- Jingle / reklam yönetimi
- Canlı yayın kontrol paneli
- Podcast kayıt ve düzenleme yazılımı

---

## 4) Bulut Altyapısı
- OneDrive üzerinden arşiv sistemi
- Program kayıtları
- Jingle ve reklam dosyaları
- Yedekleme sistemi

---

## 5) Dijital Ekosistem
- Web sitesi
- Sosyal medya entegrasyonu
- Podcast platformları (Spotify, Apple, Google)

---

## 6) Güvenlik ve Süreklilik
- Yedekli yayın sistemi
- Bulut tabanlı dosya güvenliği
- Düzenli bakım ve güncellemeler

---

## 7) Sonuç
Gurbet Radio Schweiz, modern, güvenilir ve sürdürülebilir bir yayın altyapısına sahiptir. Hem DAB+ hem dijital platformlarla geniş erişim sağlar.
