# GURBET RADIO SCHWEIZ – TAKIM

## 1) Osman – Kurucu
- Yayın vizyonu, marka stratejisi ve operasyon yönetimi
- Diaspora topluluğu ile güçlü bağlar
- Çok dilli iletişim (TR / DE / EN / CH-DE)
- Teknik altyapı ve içerik planlaması

---

## 2) Yayıncılar
- Haber sunucuları
- Müzik programcıları
- Topluluk programı sunucuları
- Gençlik içerikleri için iki dilli yayıncılar

---

## 3) Teknik Ekip
- Ses mühendisleri
- Yayın otomasyon uzmanı
- Podcast düzenleme ekibi

---

## 4) Marketing & Sosyal Medya
- İçerik üreticileri
- Sosyal medya yöneticisi
- Topluluk iletişimi

---

## 5) Danışmanlar (Opsiyonel)
- Hukuk danışmanı
- Reklam & sponsorluk danışmanı
- Digris teknik danışmanı
