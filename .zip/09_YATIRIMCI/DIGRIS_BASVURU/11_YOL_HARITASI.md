# GURBET RADIO SCHWEIZ – YOL HARİTASI

## Q1 – Hazırlık
- Marka kimliği oluşturma
- Pitch deck hazırlığı
- Teknik altyapı planlaması
- Stüdyo ekipman listesi
- Digris başvuru dosyası hazırlığı

---

## Q2 – Başvuru ve Kurulum
- Digris DAB+ başvurusu
- Stüdyo ekipmanlarının kurulumu
- Yayın otomasyon sisteminin devreye alınması
- İlk program formatlarının oluşturulması

---

## Q3 – Yayın Başlangıcı
- Test yayınları
- İlk canlı yayın
- Podcast serilerinin başlatılması
- Sosyal medya kampanyaları

---

## Q4 – Büyüme ve Gelir
- Sponsorluk anlaşmaları
- Reklam paketlerinin satışı
- Topluluk etkinlikleri
- Mobil uygulama planlaması
