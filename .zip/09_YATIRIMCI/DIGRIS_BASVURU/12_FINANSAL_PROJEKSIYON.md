# GURBET RADIO SCHWEIZ – FİNANSAL PROJEKSİYON

## 1) Giderler
### Başlangıç Giderleri
- Stüdyo ekipmanı
- Akustik düzenleme
- Yayın yazılımı
- Marka & tasarım giderleri

### Operasyonel Giderler
- Digris DAB+ ücreti
- Hosting & stream giderleri
- Lisans ücretleri
- Pazarlama & sosyal medya

---

## 2) Gelirler
### Reklam Gelirleri
- Yerel işletmeler
- Etkinlik sponsorları
- Sigorta & avukatlık sektörü

### Dijital Gelirler
- Podcast reklamları
- Web banner reklamları

### Gelecek Gelirleri
- Premium üyelik
- Özel podcast serileri

---

## 3) Finansal Öngörü
- İlk 6 ay yatırım dönemi
- 12. ayda reklam gelirlerinin artması
- 18 ayda break-even (başabaş noktası)
