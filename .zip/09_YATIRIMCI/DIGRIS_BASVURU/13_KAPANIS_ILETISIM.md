# GURBET RADIO SCHWEIZ – KAPANIŞ & İLETİŞİM

## Teşekkürler
Gurbet Radio Schweiz, İsviçre’deki Türk diasporasını bir araya getiren modern, iki dilli ve topluluk odaklı bir radyo platformudur.

**Gurbetteki Anadolunun Sesi**

---

## İletişim
- Gurbet Radio Schweiz
- Zürich, Switzerland
- info@gurbetradio.ch (placeholder)
- Web: gurbetradio.ch (placeholder)

---

## Son Mesaj
Topluluğumuzu bir araya getiren, kültürümüzü yaşatan ve yeni nesle aktaran bir medya köprüsü kuruyoruz.
