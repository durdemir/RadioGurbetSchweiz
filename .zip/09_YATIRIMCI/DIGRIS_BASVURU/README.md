# 09_YATIRIMCI – Yatırımcı Belgeleri

Pitch deck, finans projeksiyonları ve toplantı notları burada tutulur.

## Dosya İsimlendirme:
[YYYY]-PITCHDECK-[Versiyon].pdf
