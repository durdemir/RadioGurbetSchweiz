# 10_ARSIV – Arşiv

Eski yıllar, eski tasarımlar ve kullanılmayan belgeler burada saklanır.

## Dosya İsimlendirme:
[YYYY]-ARSIV-[BelgeAdi].pdf
