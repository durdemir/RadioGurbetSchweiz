Gurbet Radio Schweiz — Kurumsal Kimlik Seti
Renk paleti, tipografi, logo yönergeleri bu klasörde yer alacaktır.
