# 03_MUZIK_TELIF – Müzik ve Telif Raporları

Çalma listeleri, SUISA raporları ve metadata dosyaları burada tutulur.

## Dosya İsimlendirme:
[YYYY]-TELIF-[RaporAdi].xlsx
