# 04_MARKETING – Pazarlama ve Kampanyalar

Sosyal medya içerikleri, kampanya planları ve reklam paketleri burada tutulur.

## Dosya İsimlendirme:
[YYYY]-MKT-[KampanyaAdi].docx
